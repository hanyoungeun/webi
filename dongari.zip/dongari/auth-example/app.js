const express = require('express');
const app = express();

// 라우트 및 미들웨어 설정

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});


app.get('/login', (req, res) => {
    res.render('login'); // login.ejs 렌더링
});

app.get('/signup', (req, res) => {
    res.render('signup'); // signup.ejs 렌더링
});
