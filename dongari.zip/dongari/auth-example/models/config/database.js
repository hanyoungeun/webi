// config/database.js
const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('auth_example', 'example_user', 'example_password', {
  host: 'localhost',
  dialect: 'mysql',
});

module.exports = sequelize;
